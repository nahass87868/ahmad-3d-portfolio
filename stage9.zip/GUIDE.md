# Stage 9: smoke test becomes a deploy gate (Git Bash on Windows)

What changes: .github/workflows/deploy.yml loses ONE line (continue-on-error: true on the smoke step).
From now on a failing smoke test stops the deploy; the live site stays on the last good version.
No site file, tool or test changes.

1. Close GitHub Desktop. In Git Bash: cd to your clone, then: git pull
2. Unzip stage9.zip over the clone (Replace). GUIDE.md stays on your disk (git-ignored).
3. git diff --stat      -> expect: .github/workflows/deploy.yml | 1 -   (plus 4 graphify-out files)
4. npm run build        -> must end with OK 129 files identical to source
5. npm run test:smoke   -> must end with SMOKE TEST PASSED
6. Commit with the summary: Stage 9: smoke test is a deploy gate. Push origin to main.
7. GitHub, Actions: the run must be green and the step "npm run test:smoke" must show a green tick
   (not an orange warning). If it is red, the deploy did NOT happen: re-run once (the test uses fixed waits).
8. Open https://nahass87868.github.io/ahmad-3d-portfolio/ on your phone: intro lifts, hero shows, a project opens.
Revert: GitHub Desktop, History, right-click the commit, Revert this commit, Push origin (back to non-blocking).
Full rollback of the whole plan: branch pre-tidy (abbdbb2). Do not push to pre-tidy.
